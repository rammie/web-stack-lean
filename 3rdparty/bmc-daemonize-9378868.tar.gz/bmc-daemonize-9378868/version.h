/* Version stamp */

#ifndef VERSION
#define VERSION "1.7.4"
#endif
