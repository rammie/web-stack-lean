todo
====

* Connection pooling.
* DDL cleanup.
* Composite foreign keys (?)
