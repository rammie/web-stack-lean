Integrates the `webassets`_ library with Flask, adding support for
merging, minifying and compiling CSS and Javascript files.

Documentation of latest stable version:
    http://elsdoerfer.name/docs/flask-assets/

Documentation of development version:
    http://flask-assets.readthedocs.org/

.. _webassets: http://github.com/miracle2k/webassets
