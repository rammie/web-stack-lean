#!/usr/bin/env python
from nose import main
main()