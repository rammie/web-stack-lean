class CreditCardDefaults(object):
    CountryOfIssuance = "USA"
    IssuingBank = "NETWORK ONLY"
