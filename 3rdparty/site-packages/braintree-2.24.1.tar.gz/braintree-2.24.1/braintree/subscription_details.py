from braintree.attribute_getter import AttributeGetter

class SubscriptionDetails(AttributeGetter):
    pass
