from braintree.exceptions.braintree_error import BraintreeError

class InvalidSignatureError(BraintreeError):
    pass
