#!/usr/bin/env python

import sys
sys.path.insert(0, '..')

import main
main.app.run()
