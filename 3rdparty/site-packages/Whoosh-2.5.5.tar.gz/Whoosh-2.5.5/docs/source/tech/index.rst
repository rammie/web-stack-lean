===============
Technical notes
===============

.. toctree::
    :glob:
    :maxdepth: 2

    *
