"""Auto-generated file, do not edit by hand. 358 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_358 = [NumberFormat(pattern='(\\d{2})(\\d{3})(\\d{3,4})', format='\\1 \\2 \\3', leading_digits_pattern=['[14]|2[09]|50|7[135]']), NumberFormat(pattern='(\\d)(\\d{3})(\\d{3,4})', format='\\1 \\2', leading_digits_pattern=['[25689][1-8]|3'])]
