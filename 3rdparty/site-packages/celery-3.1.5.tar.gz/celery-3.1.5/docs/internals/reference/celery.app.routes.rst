=================================
 celery.app.routes
=================================

.. contents::
    :local:
.. currentmodule:: celery.app.routes

.. automodule:: celery.app.routes
    :members:
    :undoc-members:
