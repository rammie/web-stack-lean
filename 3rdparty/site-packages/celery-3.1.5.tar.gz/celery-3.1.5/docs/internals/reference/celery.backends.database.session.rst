========================================
 celery.backends.database.session
========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.database.session

.. automodule:: celery.backends.database.session
    :members:
    :undoc-members:
