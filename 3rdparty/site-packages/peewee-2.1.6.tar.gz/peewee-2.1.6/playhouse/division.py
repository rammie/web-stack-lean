def divides(query1, query2):
    pass
