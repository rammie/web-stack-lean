"""Auto-generated file, do not edit by hand. 595 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_595 = [NumberFormat(pattern='(\\d{2})(\\d{2})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['(?:[26]1|3[289]|4[124678]|7[123]|8[1236])'])]
