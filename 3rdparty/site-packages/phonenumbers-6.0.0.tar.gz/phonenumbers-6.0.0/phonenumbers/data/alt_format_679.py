"""Auto-generated file, do not edit by hand. 679 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_679 = [NumberFormat(pattern='(7\\d)(\\d{3})(\\d{2})', format='\\1 \\2 \\3', leading_digits_pattern=['7'])]
