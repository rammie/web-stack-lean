todo
====

* Connection pooling.
* Composite foreign keys (?)
* Convert `generate_XXX` methods on compiler to methods that generate clauses.
