====================================
 kombu.transport.sqlalchemy
====================================


.. currentmodule:: kombu.transport.sqlalchemy

.. automodule:: kombu.transport.sqlalchemy

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
