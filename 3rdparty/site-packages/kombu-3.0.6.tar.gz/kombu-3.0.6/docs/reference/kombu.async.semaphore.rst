==========================================================
 Semaphores - kombu.async.semaphore
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.async.semaphore

.. automodule:: kombu.async.semaphore
    :members:
    :undoc-members:
